# hunch Skill

Claude Code のセッションから大量の軽量 LLM タスクを並列処理するための Skill。

## セットアップ

### バイナリのビルド

プロジェクトルートで:

```bash
cargo build --release
```

バイナリは `target/release/hunch` に生成される。

### PATH に追加(任意)

```bash
# 開発中はプロジェクト内で
export PATH="$(pwd)/target/release:$PATH"

# または、システムにインストール
cargo install --path .
```

### 環境変数

API キーを環境変数に設定する(変数名は実装時に決定、`docs/CLI_REFERENCE.md` 参照)。

## 使い方の概要

Claude Code セッションから自然言語で呼び出すのが本来の用途。

```
この 300 件の issue タイトルを bug / feature / question に分類して
```

Claude Code は `SKILL.md` の説明を読み、以下のような流れで自動的にこの Skill を使う:

1. Issue データを JSONL に整形するパイプラインを組む
2. `hunch` に流す
3. 結果を集約して Claude Code が返答

## 直接実行する場合

```bash
hunch --help
```

でオプション一覧を表示。詳しくは `docs/INTERFACE.md`(方針)と `docs/CLI_REFERENCE.md`(実装後の具体仕様)を参照。

## 動作確認

実装完了後に、`examples/sample-input.jsonl` を使って動作確認できる:

```bash
# 詳細なコマンドは実装時に決定(README.md に追記される予定)
cat examples/sample-input.jsonl | hunch ...
```

## コードの構造

```
src/
├── main.rs       # エントリーポイント、CLI 引数処理
├── ...           # その他のモジュール(実装時に構成決定)
```

## 方針

このスキルの設計背景は `docs/DESIGN.md` と `docs/context/design-discussion.md` を参照。機能追加を検討する時は、まずスコープ内か確認すること。

### 基本原則

- **コード変更は扱わない**(親 Claude Code の edit ツールで)
- **Unix パイプフィルタとして振る舞う**(stdin/stdout、SIGPIPE 対応)
- **読み取り系の map 操作のみ**
- **運用で要件が固まってから機能追加**

## 関連ドキュメント

- `/docs/DESIGN.md` — 全体設計
- `/docs/REQUIREMENTS.md` — MVP と将来機能
- `/docs/INTERFACE.md` — CLI の設計方針
- `/docs/EXAMPLES.md` — 実用パターン
- `/docs/context/design-discussion.md` — 設計議論の記録(最重要)
