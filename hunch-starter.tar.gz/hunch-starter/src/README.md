# src/

Rust 実装のソースコードが入るディレクトリ。

現時点では空で、Claude Code が `docs/` を読んだ上で `main.rs` や必要なモジュールを作成する。

## 実装時のガイドライン

`docs/REQUIREMENTS.md` の MVP 要件(R-1 〜 R-8)を段階的に実装する。

### 推奨クレート(参考)

- `tokio` — 非同期ランタイム(`rt-multi-thread`, `io-std`, `io-util`, `macros` features)
- `reqwest` — HTTP クライアント(`json`, `rustls-tls` features)
- `serde` + `serde_json` — JSON シリアライズ/デシリアライズ
- `clap` — CLI 引数(`derive` feature)
- `futures` — ストリームコンビネータ
- `anyhow` または `thiserror` — エラー型
- `tracing` + `tracing-subscriber` — ログ(オプション、最初から入れなくてもよい)

### 構造の方針(提案)

1 バイナリ、モジュールで分割:

- `main.rs` — エントリーポイント、CLI 引数パース、全体の組み立て
- `cli.rs` — Clap の構造体定義
- `io.rs` — stdin/stdout/ファイル I/O、JSONL パース
- `client.rs` — HTTP クライアント、リトライロジック
- `presets.rs` — タスクプリセット定義
- `error.rs` — エラー型(必要なら)

これはあくまで提案なので、実装時により良い構造があればそれに従う。

### 実装の順序(推奨)

1. Cargo.toml と main.rs の最小動作(`--help` が動く程度)
2. stdin から 1 行読んで echo するだけの I/O スケルトン
3. OpenAI 互換エンドポイントへの単発リクエスト(並列なし)
4. JSONL 入出力
5. 並列化
6. タスクプリセット
7. リトライとバックオフ
8. 失敗の分離
9. 進捗表示
10. SIGPIPE の適切な処理

各段階で動作確認し、コミットしてから次に進む。

## テスト

- ユニットテスト: プリセットのプロンプト組み立て、JSONL パース、エラーハンドリング
- 統合テスト: モックサーバーを立てて HTTP 呼び出しをテスト
- E2E: `examples/sample-input.jsonl` を使った手動確認

## 参考ドキュメント

実装の前に以下を必ず読む:

- `../docs/DESIGN.md` — 全体設計
- `../docs/REQUIREMENTS.md` — 機能要件
- `../docs/INTERFACE.md` — CLI 設計方針
- `../docs/context/design-discussion.md` — 判断の経緯(最重要)
